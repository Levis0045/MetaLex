# You can find a list of available pre-trained models for ocropy here:

- https://github.com/tmbdev/ocropy/wiki/Models

- [CER default-model] scanrexs/libs/ocropy/models/en-default.pyrnn.gz


Copy the models into this directory to use them.


# Best model for FPC generated during [CNES-ERTIM] experations

- [CER 5.653] scanrexs/libs/ocropy/models/FPCs-models_00287000_5-653.pyrnn.gz

- [CER 4.271] scanrexs/libs/ocropy/models/REX-models_00290000_4-271.pyrnn.gz